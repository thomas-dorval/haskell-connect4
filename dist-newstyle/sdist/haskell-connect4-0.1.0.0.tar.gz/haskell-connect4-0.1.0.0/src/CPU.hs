module CPU (cpuLogic) where

import Board
import Check

cpuLogic :: Game -> (IO Game, Int)
cpuLogic (Game (board, turn)) = do
    let turnColor = if even turn then Red else Yellow
    let Board grid = board
    let half = length grid `div` 2
    if turn < 2 && getChip board (half, 0) == Empty
            then (placeChipInBoard (Game (board, turn)) half, half + 1)
            else checkForWinLose (Game (board, turn)) turnColor 3

checkForWinLose :: Game -> Chip -> Int -> (IO Game, Int)
checkForWinLose (Game (board, turn)) turnColor chipLength = do
    let (_, maybePos) = checkWin board turnColor chipLength
    case maybePos of
        Just (x, _) -> (placeChipInBoard (Game (board, turn)) x, x + 1)
        Nothing -> do 
            let (_, maybePos2) = checkWin board (Board.not turnColor) chipLength
            case maybePos2 of
                Just (x, _) -> (placeChipInBoard (Game (board, turn)) x, x + 1)
                Nothing -> if chipLength > 2
                    then checkForWinLose (Game (board, turn)) turnColor (chipLength - 1)
                    else do
                        let col = randomValidColumn board
                        (placeChipInBoard (Game (board, turn)) col, col + 1)

randomValidColumn :: Board -> Int
randomValidColumn (Board grid) = uncons [i + 1 | i <- [0..length grid - 1], Prelude.not (isColumnFull (Board grid) i)]
  where
    uncons (x:_) = x
    uncons [] = error "No valid columns available"