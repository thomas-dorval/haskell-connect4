{-# OPTIONS_GHC -Wno-missing-export-lists #-}
module Spec where

import Board
import Check
import Logic
import CPU
import InputHelper
import Test.Hspec


test :: Spec
test = do